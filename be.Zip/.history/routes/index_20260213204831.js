const express = require('express');
const router = express.Router();
const userApi = reuqire

router.use('/user', userApi);