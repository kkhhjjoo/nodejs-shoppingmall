const express = require('express');
const router = express.Router();

router.post('/', productController.createProduct);

module.exports = router;