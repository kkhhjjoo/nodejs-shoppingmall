const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const cartSchema = Schema({
 
}, { timeStamps: true });
cartSchema.methods.toJSON = function () { 
  const obj = this._doc
  delete obj.password
  delete obj.__v
  delete obj.updateAt
  delete obj.createAt
  return obj
}

const Cart = mongoose.model('Cart', userSchema);
module.exports = Cart;