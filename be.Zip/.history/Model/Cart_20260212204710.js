const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const productSchema = Schema({
 
}, { timeStamps: true });
productSchema.methods.toJSON = function () { 
  const obj = this._doc
  delete obj.password
  delete obj.__v
  delete obj.updateAt
  delete obj.createAt
  return obj
}

const Product = mongoose.model('Product', userSchema);
module.exports = Product;