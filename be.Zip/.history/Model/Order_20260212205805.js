const mongoose = require("mongoose");
const User = require('./User');
const Product = require('./Product');
const Schema = mongoose.Schema;
const orderSchema = Schema(
  {
    userId: { type: mongoose.isObjectIdOrHexString, ref: User, required: true },
    status: { type: String, default: 'preparing' },
    totalPrice: { type: Number, required: true, default: 0 },
    contact: { type: Object, required: true },
    orderNum: { type: String },
    items: [
      {
        productId: { type: mongoose.Object, ref: Product, required: true },
        price: { type: Number, required: true },
        qty: { type: Number, required: true, default: 1 },
        size: { type: String, required: true }
      }
    ]
  },
  { timeStamps: true }
);
orderSchema.methods.toJSON = function () { 
  const obj = this._doc;
  delete obj.__v;
  delete obj.updatedAt;
  return obj;
}

const Order = mongoose.model('Order', orderSchema);
module.exports = Order;