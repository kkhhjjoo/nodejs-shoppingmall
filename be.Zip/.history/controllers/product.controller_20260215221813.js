const productController = {}
productController.createProduct = async (req, res) => { 
  
}

module.exports = productController;