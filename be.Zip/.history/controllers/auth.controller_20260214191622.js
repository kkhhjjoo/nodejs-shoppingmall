const authController = {}

authController.loginWithEmail = (req, res) => { 

}

module.exports = authController