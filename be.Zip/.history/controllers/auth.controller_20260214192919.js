const authController = {}

authController.loginWithEmail = async (req, res) => { 
  try {
    const { email, password } = req.body;
    let user = await User.findOne({ email });
    if (user) { 
      const isMatch = await bcrypt.compare(password, user.password);
      if (isMatch) { 
        //token
        const token = await user.generateToken();
        return res.status(200).json({status: 'success', user, token});
      }
    }
    throw new Error('유효하지 않은 이메일 또는 패스워드입니다')
  } catch (error) { 
    res.status(400).json({status: 'fail', error: error.message})
  }
}

module.exports = authController