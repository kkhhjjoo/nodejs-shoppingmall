const User = require('../models/User');
const bcrypt = require('bcryptjs');

const userController = {}

userController.createUser = async (req, res) => {
  try {
    let { email, password, name } = req.body
    const user = await User.findOne({ email: email });
    if (user) { 
      throw new Error('유저가 이미 존재합니다')
    }
    const salt = await bcrypt.genSaltSync(10)
    password = await bcrypt.hash(password, salt)
  } catch (error) { 
    res.status(400).json({ status: 'fail', error: error.message });
  }
 }

module.exports = userController;