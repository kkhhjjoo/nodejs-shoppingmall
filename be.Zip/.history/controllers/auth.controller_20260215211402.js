const jwt = require('jsonwebtoken');
const User = require('../models/User');
const bcrypt = require('bcryptjs');
require('dotenv').config
const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;

const authController = {}

authController.loginWithEmail = async (req, res) => { 
  try {
    const { email, password } = req.body;
    let user = await User.findOne({ email });
    if (user) { 
      const isMatch = await bcrypt.compare(password, user.password);
      if (isMatch) { 
        //token
        const token = await user.generateToken();
        return res.status(200).json({status: 'success', user, token});
      }
    }
    throw new Error('유효하지 않은 이메일 또는 패스워드입니다')
  } catch (error) { 
    res.status(400).json({status: 'fail', error: error.message})
  }
}

authController.authenticate = async (req, res, next) => { 
  try {
    const tokenString = req.headers.authorization
    if (!tokenString) throw new Error('토큰이 존재하지 않습니다');
    const token = tokenString.replace('Bearer ', '');
    jwt.verify(token, )
  } catch (error) { 
    res.status(400).json({ status: 'fail', error: error.message });
  }
}

module.exports = authController