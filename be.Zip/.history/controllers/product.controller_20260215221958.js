const productController = {}
productController.createProduct = async (req, res) => { 
  try {
    const { sku, name, size, image, category, description, price, stock, status } = req.body;
  } catch (error) { 

  }
}

module.exports = productController;