const authController = {}

authController.loginWithEmail = async (req, res) => { 
  try {
    const { email, password } = req.body;
    let user = await User.findOne({ email });
    if (user) { 
      
    }
    throw
  } catch (error) { 

  }
}

module.exports = authController