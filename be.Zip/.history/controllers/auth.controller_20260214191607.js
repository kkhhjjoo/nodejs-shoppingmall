const authController = {}

authController.loginWithEmail

module.exports = authController