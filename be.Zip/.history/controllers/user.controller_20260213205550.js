const userController = {}

userController.createUser = async (req, res) => {
  try {

  } catch (error) { 
    
  }
 }

module.exports = userController;