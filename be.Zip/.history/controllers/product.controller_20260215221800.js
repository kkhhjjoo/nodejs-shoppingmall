const productController = {}
productController.createProduct = async () => { 
  
}

module.exports = productController;