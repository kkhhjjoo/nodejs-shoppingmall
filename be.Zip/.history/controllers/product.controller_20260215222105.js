const Product = require('../models/Product');

const productController = {}
productController.createProduct = async (req, res) => { 
  try {
    const { sku, name, size, image, category, description, price, stock, status } = req.body;
    const product = new Product({sku, name, size, image, category, description, price, stock, status})
  } catch (error) { 

  }
}

module.exports = productController;