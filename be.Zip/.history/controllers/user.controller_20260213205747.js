const userController = {}

userController.createUser = async (req, res) => {
  try {
    let { email, password, name } = req.body
    const user = await User.
  } catch (error) { 
    res.status(400).json({ status: 'fail', error: error.message });
  }
 }

module.exports = userController;