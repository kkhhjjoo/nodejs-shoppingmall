const authController = {}

authController.loginWithEmail = (req, res) => { 
  try {
    const { email, password } = req.body
    let user = await User.findOne({email})
  } catch (error) { 

  }
}

module.exports = authController